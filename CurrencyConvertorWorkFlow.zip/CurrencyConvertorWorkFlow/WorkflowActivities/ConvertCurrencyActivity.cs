﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Net.Http;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace CurrencyConvertorWorkFlow.WorkflowActivities
{
  public class ConvertCurrencyActivity: CodeActivity<double>
    {
        [RequiredArgument]
        public InArgument<double> Amount { get; set; }

        [RequiredArgument]
        public InArgument<string> FromCurrency { get; set; }

        [RequiredArgument]
        public InArgument<string> ToCurrency { get; set; }

        protected override double Execute(CodeActivityContext context)
        {
            double amount = Amount.Get(context);
            string fromCurrency = FromCurrency.Get(context);
            string toCurrecny = ToCurrency.Get(context);

            Task<double> task = GetExchangeRateAsync(amount, fromCurrency, toCurrecny);
            task.Wait();
            return task.Result;
        }
        private async Task<double> GetExchangeRateAsync(double amount, string from, string to)
        {
            using(HttpClient client= new HttpClient())
            {
                string url = $"https://api.exchangerate-api.com/v4/latest/{from}";
                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<ExchangeRateResponse>(jsonResponse);
                    return amount * data.Rates[to];
                }
            }
            return 0;
        }
    }
    public class ExchangeRateResponse
    {
        public string Base { get; set; }
        public Dictionary<string, double> Rates { get; set; }
    }
}
