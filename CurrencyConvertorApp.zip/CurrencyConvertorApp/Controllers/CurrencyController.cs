﻿using CurrencyConvertorApp.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace CurrencyConvertorApp.Controllers
{
    public class CurrencyController : Controller
    {
        private readonly CurrencyServiceClient _currencyServiceClient = new CurrencyServiceClient();
        // GET: Currency
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<JsonResult> ConvertCurrency(double amount, string from, string to)
        {
            double convertedAmount = await _currencyServiceClient.GetExchangeRateAsync(amount, from, to);
            return Json(new { ConvertedAmount = convertedAmount });
        }
    }
}