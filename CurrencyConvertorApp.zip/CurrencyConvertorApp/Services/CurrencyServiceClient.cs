﻿using System;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net.Http;
using System.Collections.Generic;

namespace CurrencyConvertorApp.Services
{
    public class CurrencyServiceClient
    {
        private readonly HttpClient _httpClient;
        public CurrencyServiceClient()
        {
            _httpClient = new HttpClient();
        }
        public async Task<double> GetExchangeRateAsync(double amount, string from, string to)
        {
            try
            {
                string url = $"https://api.exchangerate-api.com/v4/latest/{from}";
                HttpResponseMessage response = await _httpClient.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    var jsonResponse = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<ExchangeRateResponse>(jsonResponse);

                    if (data.Rates.ContainsKey(to))
                    {
                        double rate = data.Rates[to];
                        return amount * rate;
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error Fetching the exchange rate: " + ex.Message);
            }
            return 0;
        }
    }

    public class ExchangeRateResponse
    {
        public string Base { get; set; }
        public Dictionary<string, double> Rates { get; set; }
    }
}