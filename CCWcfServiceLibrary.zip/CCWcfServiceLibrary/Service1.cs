﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace CCWcfServiceLibrary
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class Service1 : IService1
    {
        public double ConvertCurrency(double amount, string from, string to)
        {
            Dictionary<string, double> rates = new Dictionary<string, double>
            {
                {"USD",1.0 },{"EUR", 0.85},{"GBP",0.75}
            };
            if(rates.ContainsKey(from)&& rates.ContainsKey(to))
            {
                return (amount / rates[from]) * rates[to];
            }

            return 0;
        }
    }
}
